/**
 * 华为风格演示文稿交互脚本
 * Huawei Style Presentation JavaScript
 * 
 * 功能：键盘导航、点击导航、全屏模式、幻灯片计数
 */

class HuaweiSlides {
  constructor(options = {}) {
    this.container = document.querySelector('.slides-container');
    this.wrapper = document.querySelector('.slides-wrapper');
    this.slides = document.querySelectorAll('.slide');
    this.currentIndex = 0;
    this.totalSlides = this.slides.length;
    
    // 配置选项
    this.options = {
      autoScale: options.autoScale !== false,
      showNav: options.showNav !== false,
      showFullscreen: options.showFullscreen !== false,
      loop: options.loop || false,
      ...options
    };
    
    this.init();
  }
  
  init() {
    if (this.totalSlides === 0) {
      console.warn('HuaweiSlides: 未找到幻灯片元素');
      return;
    }
    
    // 初始化幻灯片
    this.showSlide(0);
    
    // 绑定事件
    this.bindKeyboardEvents();
    this.bindClickEvents();
    this.bindTouchEvents();
    
    // 创建UI控件
    if (this.options.showNav) {
      this.createNavigation();
    }
    
    if (this.options.showFullscreen) {
      this.createFullscreenButton();
    }
    
    // 自适应缩放
    if (this.options.autoScale) {
      this.handleResize();
      window.addEventListener('resize', () => this.handleResize());
    }
    
    // 更新页码
    this.updatePageNumbers();
    
    console.log(`HuaweiSlides: 已加载 ${this.totalSlides} 张幻灯片`);
  }
  
  /**
   * 显示指定索引的幻灯片
   */
  showSlide(index) {
    // 处理边界
    if (this.options.loop) {
      if (index < 0) index = this.totalSlides - 1;
      if (index >= this.totalSlides) index = 0;
    } else {
      if (index < 0) index = 0;
      if (index >= this.totalSlides) index = this.totalSlides - 1;
    }
    
    // 移除所有active状态
    this.slides.forEach(slide => slide.classList.remove('active'));
    
    // 激活当前幻灯片
    this.slides[index].classList.add('active');
    this.currentIndex = index;
    
    // 更新导航计数器
    this.updateCounter();
    
    // 触发自定义事件
    this.container.dispatchEvent(new CustomEvent('slidechange', {
      detail: { index: this.currentIndex, total: this.totalSlides }
    }));
  }
  
  /**
   * 下一张幻灯片
   */
  next() {
    this.showSlide(this.currentIndex + 1);
  }
  
  /**
   * 上一张幻灯片
   */
  prev() {
    this.showSlide(this.currentIndex - 1);
  }
  
  /**
   * 跳转到第一张
   */
  first() {
    this.showSlide(0);
  }
  
  /**
   * 跳转到最后一张
   */
  last() {
    this.showSlide(this.totalSlides - 1);
  }
  
  /**
   * 键盘事件绑定
   */
  bindKeyboardEvents() {
    document.addEventListener('keydown', (e) => {
      switch (e.key) {
        case 'ArrowRight':
        case 'ArrowDown':
        case ' ':
        case 'PageDown':
          e.preventDefault();
          this.next();
          break;
        case 'ArrowLeft':
        case 'ArrowUp':
        case 'PageUp':
          e.preventDefault();
          this.prev();
          break;
        case 'Home':
          e.preventDefault();
          this.first();
          break;
        case 'End':
          e.preventDefault();
          this.last();
          break;
        case 'f':
        case 'F':
          e.preventDefault();
          this.toggleFullscreen();
          break;
        case 'Escape':
          if (document.fullscreenElement) {
            document.exitFullscreen();
          }
          break;
      }
    });
  }
  
  /**
   * 点击事件绑定
   */
  bindClickEvents() {
    this.container.addEventListener('click', (e) => {
      // 忽略按钮和链接点击
      if (e.target.closest('button, a, .slide-nav')) return;
      
      const rect = this.container.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const threshold = rect.width / 3;
      
      if (x < threshold) {
        this.prev();
      } else {
        this.next();
      }
    });
  }
  
  /**
   * 触摸事件绑定（移动端支持）
   */
  bindTouchEvents() {
    let startX = 0;
    let startY = 0;
    
    this.container.addEventListener('touchstart', (e) => {
      startX = e.touches[0].clientX;
      startY = e.touches[0].clientY;
    }, { passive: true });
    
    this.container.addEventListener('touchend', (e) => {
      const endX = e.changedTouches[0].clientX;
      const endY = e.changedTouches[0].clientY;
      const diffX = startX - endX;
      const diffY = startY - endY;
      
      // 水平滑动距离大于垂直，且超过50px
      if (Math.abs(diffX) > Math.abs(diffY) && Math.abs(diffX) > 50) {
        if (diffX > 0) {
          this.next();
        } else {
          this.prev();
        }
      }
    }, { passive: true });
  }
  
  /**
   * 创建导航控件
   */
  createNavigation() {
    const nav = document.createElement('div');
    nav.className = 'slide-nav';
    nav.innerHTML = `
      <button class="nav-prev" title="上一页 (←)">◀</button>
      <span class="slide-counter">1 / ${this.totalSlides}</span>
      <button class="nav-next" title="下一页 (→)">▶</button>
    `;
    
    this.container.appendChild(nav);
    
    // 绑定按钮事件
    nav.querySelector('.nav-prev').addEventListener('click', (e) => {
      e.stopPropagation();
      this.prev();
    });
    
    nav.querySelector('.nav-next').addEventListener('click', (e) => {
      e.stopPropagation();
      this.next();
    });
    
    this.counterElement = nav.querySelector('.slide-counter');
  }
  
  /**
   * 创建全屏按钮
   */
  createFullscreenButton() {
    const btn = document.createElement('button');
    btn.className = 'fullscreen-btn';
    btn.innerHTML = '全屏 (F)';
    btn.title = '切换全屏模式';
    
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      this.toggleFullscreen();
    });
    
    this.container.appendChild(btn);
    this.fullscreenBtn = btn;
    
    // 监听全屏变化
    document.addEventListener('fullscreenchange', () => {
      this.fullscreenBtn.innerHTML = document.fullscreenElement ? '退出全屏 (Esc)' : '全屏 (F)';
    });
  }
  
  /**
   * 切换全屏模式
   */
  toggleFullscreen() {
    if (!document.fullscreenElement) {
      this.container.requestFullscreen().catch(err => {
        console.warn('无法进入全屏模式:', err);
      });
    } else {
      document.exitFullscreen();
    }
  }
  
  /**
   * 更新计数器
   */
  updateCounter() {
    if (this.counterElement) {
      this.counterElement.textContent = `${this.currentIndex + 1} / ${this.totalSlides}`;
    }
  }
  
  /**
   * 更新页面内的页码显示
   */
  updatePageNumbers() {
    this.slides.forEach((slide, index) => {
      const pageNumEl = slide.querySelector('.page-number');
      if (pageNumEl) {
        pageNumEl.textContent = index + 1;
      }
    });
  }
  
  /**
   * 处理窗口缩放
   */
  handleResize() {
    const containerWidth = window.innerWidth;
    const containerHeight = window.innerHeight;
    const slideWidth = 1920;
    const slideHeight = 1080;
    
    const scaleX = containerWidth / slideWidth;
    const scaleY = containerHeight / slideHeight;
    const scale = Math.min(scaleX, scaleY);
    
    this.wrapper.style.transform = `scale(${scale})`;
  }
}

// 自动初始化
document.addEventListener('DOMContentLoaded', () => {
  // 检查是否存在幻灯片容器
  if (document.querySelector('.slides-container')) {
    window.huaweiSlides = new HuaweiSlides();
  }
});

// 导出供外部使用
if (typeof module !== 'undefined' && module.exports) {
  module.exports = HuaweiSlides;
}
