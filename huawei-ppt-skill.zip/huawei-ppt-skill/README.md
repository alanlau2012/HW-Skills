# 华为风格演示文稿生成 Skill

将华为PPT模板完整复刻为HTML格式，可用于生成专业的华为风格演示文稿。

## 文件结构

```
huawei-ppt-skill/
├── huawei-slides.css    # 核心样式文件
├── huawei-slides.js     # 交互脚本
├── template.html        # 基础模板（带占位符）
├── example.html         # 完整示例
└── assets/
    └── huawei-logo.svg  # 华为Logo
```

## 快速开始

1. 复制 `template.html` 并重命名
2. 替换 `{{占位符}}` 为实际内容
3. 在浏览器中打开即可演示

## 页面类型

### 1. 封面页 (`.slide-cover`)
全屏背景图、标题、元信息、L形装饰框、Logo

```html
<section class="slide slide-cover" style="background-image: url('背景图URL');">
  <div class="cover-content">
    <h1 class="cover-title">演示文稿标题</h1>
    <div class="cover-meta">
      <span>部门：xxx</span>
      <span>作者：xxx</span>
      <span>日期：xxx</span>
    </div>
  </div>
  <div class="l-frame"></div>
  <div class="cover-footer">
    <span class="security-level">Security Level: Internal</span>
    <div class="huawei-logo">
      <img src="assets/huawei-logo.svg" alt="HUAWEI">
    </div>
  </div>
</section>
```

### 2. 目录页 (`.slide-toc`)
浅灰背景、红线标题装饰

```html
<section class="slide slide-toc">
  <div class="toc-header">
    <h2 class="toc-title">目录</h2>
  </div>
  <div class="toc-content">
    <ul class="toc-list">
      <li class="toc-item">
        <span class="toc-number">1.</span>
        <span class="toc-text">章节名称</span>
      </li>
    </ul>
  </div>
</section>
```

### 3. 内容页 (`.slide-content`)
白色背景、左侧红线、页脚

```html
<section class="slide slide-content">
  <div class="content-header">
    <h2 class="content-title">页面标题</h2>
    <p class="content-subtitle">副标题</p>
  </div>
  <div class="content-body">
    <!-- 内容区域 -->
  </div>
  <footer class="content-footer">
    <div class="page-info">
      <span class="page-number">3</span>
      <span class="confidential">Huawei Confidential</span>
    </div>
    <div class="huawei-logo logo-small">
      <img src="assets/huawei-logo.svg" alt="HUAWEI">
    </div>
  </footer>
</section>
```

### 4. 结尾页 (`.slide-end`)
Thank you 布局、愿景、版权声明

```html
<section class="slide slide-end">
  <div class="end-left">
    <h2 class="thank-you">Thank you.</h2>
  </div>
  <div class="end-right">
    <p class="vision-cn">愿景中文</p>
    <p class="vision-en">愿景英文</p>
    <p class="copyright">版权声明</p>
    <div class="huawei-logo logo-large">
      <img src="assets/huawei-logo.svg" alt="HUAWEI">
    </div>
  </div>
</section>
```

## 布局辅助类

| 类名 | 说明 |
|------|------|
| `.grid-2` | 两栏布局 |
| `.grid-3` | 三栏布局 |
| `.grid-4` | 四栏布局 |
| `.card` | 卡片容器 |
| `.stat-number` | 大数字统计 |
| `.text-center` | 文字居中 |

## 键盘快捷键

| 按键 | 功能 |
|------|------|
| `→` `↓` `Space` | 下一页 |
| `←` `↑` | 上一页 |
| `Home` | 第一页 |
| `End` | 最后一页 |
| `F` | 全屏模式 |
| `Esc` | 退出全屏 |

## 设计规范

- **华为红**: `#C7000B`
- **背景色**: 白色 `#FFFFFF` / 浅灰 `#F5F5F5`
- **文字色**: 黑色 `#000000` / 深灰 `#333333`
- **比例**: 16:9 (1920×1080)
- **字体**: HarmonyOS Sans / Microsoft YaHei

## 本地预览

```bash
# 使用 Node.js
npx serve

# 然后访问 http://localhost:3000/example.html
```

## 许可

仅供学习和内部使用，华为Logo及品牌标识归华为技术有限公司所有。
