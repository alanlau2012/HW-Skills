/**
 * 华为风格演示文稿交互脚本
 */
class HuaweiSlides {
  constructor() {
    this.container = document.querySelector('.slides-container');
    this.wrapper = document.querySelector('.slides-wrapper');
    this.slides = document.querySelectorAll('.slide');
    this.currentIndex = 0;
    this.totalSlides = this.slides.length;
    if (this.totalSlides > 0) this.init();
  }

  init() {
    this.showSlide(0);
    this.bindEvents();
    this.createNav();
    this.handleResize();
    window.addEventListener('resize', () => this.handleResize());
  }

  showSlide(index) {
    if (index < 0) index = 0;
    if (index >= this.totalSlides) index = this.totalSlides - 1;
    this.slides.forEach(s => s.classList.remove('active'));
    this.slides[index].classList.add('active');
    this.currentIndex = index;
    this.updateCounter();
  }

  next() { this.showSlide(this.currentIndex + 1); }
  prev() { this.showSlide(this.currentIndex - 1); }

  bindEvents() {
    document.addEventListener('keydown', e => {
      if (['ArrowRight','ArrowDown',' ','PageDown'].includes(e.key)) { e.preventDefault(); this.next(); }
      if (['ArrowLeft','ArrowUp','PageUp'].includes(e.key)) { e.preventDefault(); this.prev(); }
      if (e.key === 'Home') { e.preventDefault(); this.showSlide(0); }
      if (e.key === 'End') { e.preventDefault(); this.showSlide(this.totalSlides - 1); }
      if (e.key === 'f' || e.key === 'F') { e.preventDefault(); this.toggleFullscreen(); }
    });

    this.container.addEventListener('click', e => {
      if (e.target.closest('button, a, .slide-nav')) return;
      const rect = this.container.getBoundingClientRect();
      e.clientX - rect.left < rect.width / 3 ? this.prev() : this.next();
    });
  }

  createNav() {
    const nav = document.createElement('div');
    nav.className = 'slide-nav';
    nav.innerHTML = `<button class="nav-prev">◀</button><span class="slide-counter">1 / ${this.totalSlides}</span><button class="nav-next">▶</button>`;
    this.container.appendChild(nav);
    nav.querySelector('.nav-prev').onclick = e => { e.stopPropagation(); this.prev(); };
    nav.querySelector('.nav-next').onclick = e => { e.stopPropagation(); this.next(); };
    this.counterEl = nav.querySelector('.slide-counter');

    const btn = document.createElement('button');
    btn.className = 'fullscreen-btn';
    btn.innerHTML = '全屏 (F)';
    btn.onclick = e => { e.stopPropagation(); this.toggleFullscreen(); };
    this.container.appendChild(btn);
  }

  updateCounter() {
    if (this.counterEl) this.counterEl.textContent = `${this.currentIndex + 1} / ${this.totalSlides}`;
  }

  toggleFullscreen() {
    document.fullscreenElement ? document.exitFullscreen() : this.container.requestFullscreen();
  }

  handleResize() {
    const scale = Math.min(window.innerWidth / 1920, window.innerHeight / 1080);
    this.wrapper.style.transform = `scale(${scale})`;
  }
}

document.addEventListener('DOMContentLoaded', () => {
  if (document.querySelector('.slides-container')) window.huaweiSlides = new HuaweiSlides();
});
