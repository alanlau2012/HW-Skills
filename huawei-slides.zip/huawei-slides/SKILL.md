---
name: huawei-slides
description: Create professional Huawei-style HTML presentations. Use this skill when users want to create presentations, slideshows, or pitch decks in Huawei corporate visual style, including cover pages, table of contents, content pages with red accent decorations, and thank-you ending pages. Triggers on requests like "create a Huawei-style presentation", "make slides in Huawei format", "华为风格PPT", "华为演示文稿".
---

# Huawei-Style HTML Presentation Generator

Generate professional presentations following Huawei's corporate visual identity.

## Design Specifications

| Element | Value |
|---------|-------|
| Aspect Ratio | 16:9 (1920×1080) |
| Primary Color | White #FFFFFF |
| Secondary Color | Light Gray #F5F5F5 |
| Accent Color | Huawei Red #C7000B |
| Text Colors | Black #000000, Dark Gray #333333 |
| Fonts | HarmonyOS Sans, Microsoft YaHei |

## Page Types

### 1. Cover Page (`.slide-cover`)

Full-screen background, title, metadata, L-shaped red frame decoration, logo at bottom-right.

```html
<section class="slide slide-cover active" style="background: linear-gradient(...);">
  <div class="cover-content">
    <h1 class="cover-title">演示标题</h1>
    <div class="cover-meta">
      <span>部门：XXX</span>
      <span>作者：XXX</span>
      <span>日期：XXXX年XX月</span>
    </div>
  </div>
  <div class="l-frame"></div>
  <div class="cover-footer">
    <span class="security-level">Security Level: Internal</span>
    <div class="huawei-logo"><img src="huawei-logo.svg" alt="HUAWEI"></div>
  </div>
</section>
```

### 2. Table of Contents (`.slide-toc`)

Light gray background, red underline on title.

```html
<section class="slide slide-toc">
  <div class="toc-header"><h2 class="toc-title">目录</h2></div>
  <div class="toc-content">
    <ul class="toc-list">
      <li class="toc-item"><span class="toc-number">1.</span><span>章节名</span></li>
    </ul>
  </div>
</section>
```

### 3. Content Page (`.slide-content`)

White background, red vertical line on left of header, footer with page number and logo.

```html
<section class="slide slide-content">
  <div class="content-header">
    <h2 class="content-title">页面标题</h2>
    <p class="content-subtitle">副标题</p>
  </div>
  <div class="content-body">
    <div class="content-text">内容区域</div>
  </div>
  <footer class="content-footer">
    <div class="page-info">
      <span class="page-number">3</span>
      <span class="confidential">Huawei Confidential</span>
    </div>
    <div class="huawei-logo logo-small"><img src="huawei-logo.svg" alt="HUAWEI"></div>
  </footer>
</section>
```

### 4. Ending Page (`.slide-end`)

"Thank you." on left, vision statement and copyright on right.

```html
<section class="slide slide-end">
  <div class="end-left"><h2 class="thank-you">Thank you.</h2></div>
  <div class="end-right">
    <p class="vision-cn">把数字世界带入每个人、每个家庭、每个组织，构建万物互联的智能世界。</p>
    <p class="vision-en">Bring digital to every person, home, and organization...</p>
    <p class="copyright">Copyright©2025 Huawei Technologies Co., Ltd.</p>
    <div class="huawei-logo logo-large"><img src="huawei-logo.svg" alt="HUAWEI"></div>
  </div>
</section>
```

## Layout Helpers

| Class | Description |
|-------|-------------|
| `.grid-2` | Two-column layout |
| `.grid-3` | Three-column layout |
| `.grid-4` | Four-column layout |
| `.card` | Card container with gray background |
| `.stat-number` | Large red numbers for statistics |
| `.text-center` | Centered text |

## Workflow

1. Copy all files from `assets/` to output directory
2. Create HTML file based on `template.html`
3. Replace placeholders with actual content
4. Add `.slide-content` sections as needed
5. Ensure first slide has `active` class
6. Update page numbers in footers

## Assets

- `huawei-slides.css` - Core styles
- `huawei-slides.js` - Navigation and interaction
- `huawei-logo.svg` - Huawei logo
- `template.html` - Base HTML template

## Keyboard Shortcuts

| Key | Action |
|-----|--------|
| → ↓ Space | Next slide |
| ← ↑ | Previous slide |
| Home | First slide |
| End | Last slide |
| F | Toggle fullscreen |
